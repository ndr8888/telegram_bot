from random import randint

for i in range(10):
    print(randint(1, 3))